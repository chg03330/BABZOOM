﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

using BABZOOM.Network;
using Newtonsoft.Json;

namespace DoitDoit
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private async void Login_Clicked(object sender, EventArgs e)
        {
            String id = Entry_ID.Text;
            String pw = PASSWORD.Text;

            Dictionary<string, string> post = new Dictionary<string, string>();
            post["ID"] = id;
            post["Password"] = pw;

            FirebaseServer server = new FirebaseServer();
            string result = await server.FirebaseRequest("SignIn", post);

            Dictionary<string, string> resultdic = JsonConvert.DeserializeObject<Dictionary<string, string>>(result);

            await DisplayAlert(resultdic["Result"], resultdic["Context"], "Cancel");

            await Navigation.PushModalAsync(new Main());
        }

        private void SignUp_Clicked(object sender, EventArgs e)
        {
            Navigation.PushModalAsync(new SignUp());
        }
        
        private void Cancel_Clicked(object sender, EventArgs e)
        {

        }
    }
}
